#include <stdio.h>
#include <stdlib.h>
#include "ArvoreBinaria.h"

int main()
{
	ArvBin* raiz;
	int opcao, valor, x, sim;

	while(1)
	{
		printf("\nÁRVORE BINÁRIA\n\n1- Insere valor;\n2- Consulta;\n3- "
                        "Remove;\n4- Sair.\n\nOpção: ");
                scanf("%d",&opcao);
		switch(opcao)
		{	case 1:
				printf("\nDigite um valor para inserir na "
                                        "Árvore binária: ");
				scanf("%d", &valor);
				x = insere_ArvBin(raiz,valor);
                                if(x)
                                    printf("\nValor inserido corretamente!\n");
                                else{
                                    raiz = cria_ArvBin();
                                    printf("\nÁrvore criada e valor inserido "
                                            "corretamente!\n");
                                }
				break;
			case 2:	
				printf("\nDigite um valor para consultar se "
                                        "existe na Árvore (A raiz inicial não "
                                        "será verificada): "); 	
				scanf("%d", &valor);                                
				x = consulta_ArvBin(raiz, valor); 
                                if(x)
                                    printf("\nValor encontrado "
                                            "corretamente!\n");
                                else
                                    printf("\nValor não encontrado!\n");                                
 				break;	
			case 3:
				printf("\nDigite o valor a ser excluído: ");
				scanf("%d", &valor);
				x = remove_ArvBin(raiz, valor); 
                                if(x==1)
                                    printf("\nValor excluído corretamente!\n");
                                else
                                {
                                    if(x==2)
                                        printf("Árvore vazia!");
                                    else
                                    {
                                        printf("Valor não encontrado! Caso ele "
                                                "seja o item raiz, Deseja "
                                                "liberar Árvore (Digite 1. Em "
                                                "seguida, você sairá do "
                                                "programa. Caso contrário, "
                                                "tecle 0.)?\n");
                                        scanf("%d",&sim);
                                        if (sim)
                                        {
                                            libera_ArvBin(raiz);
                                            printf("\nÁrvore liberada, valor "
                                                    "excluído e programa "
                                                    "encerrando!\n"); 
                                            exit(0);
                                        }
                                    }
                                }
   				break;
			case 4:
				exit(0);
			default:
				printf("Opção incorreta!");
				break;
		}
	}
	return 0;
}


